# vanillaToVueJS

Proof Of Competence: à partir d'une maquette XD et d'une API, création d'une application responsive en VanillaJS puis en VueJS

## HOW To

Just import and open index.html

## TODO List

* ~~Install Adobe XD~~
* ~~Readme.md~~
* ~~Affichage des produits via l'API~~
* ~~Bouton cliquable ssi prixbase != prixactuel~~
* ~~Disable envoie du formulaire au clic sur "entrer" dans le champ prix~~
* ~~id plutot que i, plus sûr~~
* ~~API page détail~~
* ~~Intégration home, desktop HTML / CSS - Roboto~~
* ~~Version mobile responsive - cohérente et ergonomique~~
* ~~Intégration de la page détail~~
* ~~Amélioration de l'intégration~~
* ~~Vue liste~~

* ~~refaire page produit~~
* ~~refacto 1~~
* ~~Less~~
* ~~prix TTC modifié dynamiquement~~

* Refacto en module, class prod
* Refactorisation via VueJS

* Modification du prix /!\
* Persistence de donnée via localstorage
* Websockets pour MAJ dans le cas d'une utilisation simultanée